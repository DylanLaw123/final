https://covid19.mathdro.id/api/confirmed

{
    "confirmed":{
        "value":218814,
        "detail":"https://covid19.mathdro.id/api/confirmed"
    },
    
    "recovered":{
        "value":84113,
        "detail":"https://covid19.mathdro.id/api/recovered"
    },
    
    "deaths":{
        "value":8810,
        "detail":"https://covid19.mathdro.id/api/deaths"
    },
    
    "dailySummary":"https://covid19.mathdro.id/api/daily","dailyTimeSeries":{"pattern":"https://covid19.mathdro.id/api/daily/[dateString]","example":"https://covid19.mathdro.id/api/daily/2-14-2020"},"image":"https://covid19.mathdro.id/api/og","source":"https://github.com/mathdroid/covid19","countries":"https://covid19.mathdro.id/api/countries","countryDetail":{"pattern":"https://covid19.mathdro.id/api/countries/[country]","example":"https://covid19.mathdro.id/api/countries/USA"},"lastUpdate":"2020-03-19T04:33:18.000Z"}





https://www.youtube.com/watch?v=B85s0cjlitE

https://www.worldometers.info/coronavirus/




https://www.producthunt.com/posts/coronavirus-data-api

https://wordpress.org/plugins/corona-virus-data/

https://pipedream.com/@pravin/http-api-for-latest-wuhan-coronavirus-data-2019-ncov-p_G6CLVM/readme

https://pipedream.com/@pravin/http-api-for-latest-wuhan-coronavirus-data-2019-ncov-p_G6CLVM/edit

https://github.com/CSSEGISandData/COVID-19

https://www.mongodb.com/blog/post/tracking-coronavirus-news-with-mongodb-charts